<?php $__env->startSection('content'); ?>

  
    
     <?php echo $__env->make('components.section-01', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
     <?php echo $__env->make('components.section-03', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
     <?php echo $__env->make('components.section-clientreview', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

     <?php echo $__env->make('components.other-categories', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>






<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>