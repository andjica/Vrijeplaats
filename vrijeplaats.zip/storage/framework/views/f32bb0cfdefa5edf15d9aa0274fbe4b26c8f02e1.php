<?php $__env->startSection('content'); ?>
<div class="page-container">
    <?php echo $__env->make('user.top-campain', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div class="container">
<?php
        $userId = auth()->user()->id;
        $user =\App\UserView::where('user_id', $userId)->first();
        if(!$user):
?>
<div class="alert alert-warning fade show fadeIn" role="alert">
    
				<button type="button" class="close" data-dismiss="alert" aria-label="Close">
			    	<span aria-hidden="true">&times;</span>
			  	</button>
  <h4 class="alert-heading">Goed gedaan!</h4>
  <p>Bedankt voor uw succesvolle registratie op de website van VrijePlaats. Om op het platform te surfen en uw advertenties toe te voegen, is het noodzakelijk om uw profiel in te vullen. 
     </p>
  <hr>
  <p class="mb-0"> Surf daarna gratis en maak je eigen berichten</p>
  <img src="<?php echo e(asset('/images/')); ?>/logosmall.jpeg" alt="Vrijeplaats" width="100px;" class="img-rounded-circle">

</div>
<?php 
    endif;
?>



<div class="page-content-wrapper d-flex flex-column">
<h1 class="font-size-h4 mb-4 font-weight-normal">My Profile</h1>
<div class="row">
<div class="col-lg-5">
<?php echo $__env->make('user.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</div>

<div class="col-lg-6 mb-4 mb-lg-0">
<?php if(session('success')): ?>
<div class="alert alert-success">
    <?php echo e(session('success')); ?>

</div>
<?php endif; ?>
<?php
        $userId = auth()->user()->id;
        $user =\App\UserView::where('user_id', $userId)->first();
        if(!$user):
?>
        <?php echo $__env->make('user.insert-info', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php 
    
    else:
?>
        <?php echo $__env->make('user.edit-info', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php 
    
    endif;
?>
</div>
</div>
</div>
</div>

</div>
<div class="mt-6">
© 2020 Thedir. All Rights Reserved.
</div>
</div>
</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>