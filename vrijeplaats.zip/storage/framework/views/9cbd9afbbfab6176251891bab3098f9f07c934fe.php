<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row justify-content-center mb-5">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('Verifieer je e-mailadres')); ?></div>

                <div class="card-body">
                    <?php if(session('resent')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(__('Er is een nieuwe verificatielink naar uw e-mailadres verzonden.')); ?>

                        </div>
                    <?php endif; ?>

                    <?php echo e(__('Controleer voordat u doorgaat uw e-mail op een verificatielink. ')); ?>

                    <?php echo e(__('Als je de e-mail niet hebt ontvangen,')); ?> <a href="<?php echo e(route('verification.resend')); ?>"><?php echo e(__(' klik dan hier om een ​​nieuwe aan te vragen.')); ?></a>.
                </div>
            </div>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>