<!doctype html>
<html lang="en">
<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<meta http-equiv="X-UA-Compatible" content="ie=edge">
<title>Vrijeplaats | </title>
<script
      src="https://use.fontawesome.com/releases/v5.15.4/js/all.js"
      data-auto-a11y="true"
    ></script>

<script src="/cdn-cgi/apps/head/2oc_RD5SS6wgN5SiQnSEnWVNHg8.js"></script>
<link href="https://fonts.googleapis.com/css?family=Work+Sans:200,300,400,500,600,700,800,900&display=swap" rel="stylesheet">
<link rel="stylesheet" href="<?php echo e(asset('/css/')); ?>/fontawesome.css">
<link rel="stylesheet" href="<?php echo e(asset('/css/')); ?>/magnific-popup.css">
<link rel="stylesheet" href="<?php echo e(asset('/css/')); ?>/slick.css">
<link rel="stylesheet" href="<?php echo e(asset('/css/')); ?>/animate.css">

<link rel="stylesheet" href="<?php echo e(asset('/css/')); ?>/style.css">
</head>
<body>
<div id="site-wrapper" class="site-wrapper home-main">
<?php echo $__env->make('components.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<div class="content-wrap">
<?php echo $__env->yieldContent('content'); ?>

</div>
<?php echo $__env->make('components.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</div>


</body>
</html>