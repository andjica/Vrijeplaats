<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Summernote</title>
  <link href="https://stackpath.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <link href="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote.min.js"></script>
</head>
<body>
    <?php echo $__env->make('user.nav', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div class="container">
<div class="row lh-18">
<div class="col-md-6 ">
<div class="card border-0 p-0">
<img src="<?php echo e(asset('/images/')); ?>/other/services1.jpg" alt="Submit listing 01" class="card-img-top">
<div class="card-body px-0 pt-6">
<div class="form-group mb-4">
<div class="text-dark font-weight-semibold font-size-md mb-2 lh-15">Listing Tittle
<a href="#" class="text-darker-light d-inline-block ml-2" data-toggle="tooltip" data-placement="top" title="" data-original-title="Title for listing"><i class="fas fa-question-circle"></i></a>
</div>
<input type="text" class="form-control" placeholder="Staple &amp; Fancy Hotel">
<input type="text" class="form-control" placeholder="Tagline Example: Best Express Mexican Grill">
</div>
<div class="form-group mb-4">
<div class="mb-2 d-flex align-items-center lh-15">
<label class="mb-0 text-dark font-weight-semibold font-size-md lh-15" for="city">City</label>
<a href="#" class="text-darker-light d-inline-block ml-2" data-toggle="tooltip" data-placement="top" title="" data-original-title="Region of listing">
<i class="fas fa-question-circle"></i></a></div>
    <input type="text" name="autocomplete-city" id="autocomplete-city" class="form-control" placeholder="Enter City">
    <input type="hidden" id="citylatitude" name="citylatitude" class="form-control">
    <input type="hidden" name="citylongitude" id="citylongitude" class="form-control">
</div>
<div class="form-group mb-4">
<label for="phone" class="text-dark font-weight-semibold font-size-md mb-2 lh-15">Phone</label>
<input type="text" id="phone" class="form-control" placeholder="123-456-789">
</div>
<div class="form-group mb-4">
<div class="mb-2 d-flex align-items-center lh-15">
<label class="mb-0 text-dark font-weight-semibold font-size-md lh-15" for="address">Full Address
(Geolocation) </label>

    <input type="hidden" id="latitude" name="latitude" class="form-control">
    <input type="hidden" name="longitude" id="longitude" class="form-control">
    <input type="text" name="autocomplete" id="autocomplete" class="form-control" placeholder="Enter Location">

</div>
</div>
<div class="form-group mb-4">
<label for="website" class="text-dark font-weight-semibold font-size-md mb-2 lh-15">Website</label>
<input type="text" id="website" class="form-control" placeholder="http://">
</div>
<div class="form-group mb-4">
<label for="ticket" class="text-dark font-weight-semibold font-size-md mb-2 lh-15">Nummber of valible tickets</label>
<input type="text" id="tickets" class="form-control" name="tickets" placeholder="">
</div>
<div class="form-group">
<label for="datetime" class="text-dark font-weight-semibold font-size-md mb-2 lh-15">Ticket valid until</label>
<input type="date" id="start" name="trip-start" value="2021-10-01" min="2021-10-01" max="" class="form-control" name="validuntil">
</div>
</div>
</div>
</div>
<div class="col-md-6 ">
<div class="card border-0 p-0">
<img src="<?php echo e(asset('/images/')); ?>/other/services.jpg" alt="Submit listing 02" class="card-img-top img-fluid">
<div class="form-group">
<label><strong>Description :</strong></label>
<div id="summernote">Hello Summernote</div>

<textarea class="summernote" name="description"></textarea>
<?php if($errors->has('description')): ?>  <p style="color:red;"><?php echo e($errors->first('description')); ?></p> <?php endif; ?>

</div>
<div class="form-group mb-4">
<label for="category" class="text-dark font-weight-semibold font-size-md mb-2 lh-15">Category</label>
<select id="category" class="form-control color-gray">
<option selected="">Choose your business category</option>
</select>
</div>
<div class="form-row mb-4">
<div class="col">
<label for="price-form" class="text-dark font-weight-semibold font-size-md mb-2 lh-15">Current price</label>
<input type="text" class="form-control" name="currentprice">
</div>
<div class="col">
<label class="text-dark font-weight-semibold font-size-md mb-2 lh-15" for="price-to">Price before discount</label>
<input type="text" class="form-control" name="firstprice">

</div>
</div>
<div class="form-group mb-4 mt-4 bg-light">
<label class="text-dark font-weight-semibold font-size-md mb-2 lh-15">Images
</label>
 <div class="dropzone upload-file text-center dz-clickable" data-uploader="true" id="myDropzone" data-uploader-url="./page-submit-listing.html">
<div class="dz-default dz-message">
<div class="title">
<span>Drag &amp; Drop files here</span>
<span>or</span>
</div>
<div class="upload-btn-wrapper">
<button class="btn btn-primary font-size-md px-5">Browse Files</button>
<input type="file">
</div>
</div>
</div>
<div class="mt-3">The first image will be shown on listing
cards.
</div>
</div>
</div>
</div>
<div class="card-body px-0 pt-6">

<div class="form-group mb-4">
<label class="text-dark font-weight-semibold font-size-md mb-2 lh-15">Social</label>
<div class="row mb-4">
<div class="col-md-6 mb-4 mb-md-0">
<input type="text" class="form-control" placeholder="Your Twitter URL">
</div>
<div class="col-md-6">
<input type="text" class="form-control" placeholder="Your Facebook URL">
</div>
</div>
<div class="row mb-4">
<div class="col-md-6 mb-4 mb-md-0">
<input type="text" class="form-control" placeholder="Your Linkedln URL">
</div>
<div class="col-md-6">
<input type="text" class="form-control" placeholder="Your Google Plus URL">
</div>
</div>
<div class="row mb-4">
<div class="col-md-6 mb-4 mb-md-0">
<input type="text" class="form-control" placeholder="Your Youtube URL">
</div>
<div class="col-md-6">
<input type="text" class="form-control" placeholder="Your Instagram URL">
</div>
</div>
</div>
<div class="form-group mb-4">
<div class="mb-2 d-flex align-items-center lh-15">
<label class="mb-0 text-dark font-weight-semibold font-size-md lh-15" for="tags">Tags or keywords (Comma
seprated)</label>
<a href="#" class="text-darker-light d-inline-block ml-2" data-toggle="tooltip" data-placement="top" title="" data-original-title="Tags or keyword for search easier"><i class="fas fa-question-circle"></i></a>
</div>
<textarea id="tags" class="form-control" placeholder="Enter tags or keywords comma sperated..."></textarea>
</div>
</div>
</div>
</div>
  <script>
    $(document).ready(function() {
        $('#summernote').summernote();
    });
  </script>
</body>
</html>