<form id="editinfo" action="<?php echo e(asset('edit-user-info')); ?>" method="POST" enctype="multipart/form-data">
<?php echo csrf_field(); ?>
<div class="card rounded-0 border-0 bg-white px-4 pt-3 pb-6">
<div class="card-header p-0 bg-transparent"><h5 class="card-title text-capitalize">Profiel Details
</h5>
</div>
<div class="card-body px-0 pt-4 pb-0">
<div class="profile media d-flex align-items-center flex-wrap">

<div class="image mb-4">
<?php if(auth()->user()->userview->image != null): ?>
<img src="<?php echo e(asset('/images')); ?>/users/<?php echo e(auth()->user()->userview->image); ?>" alt="User image" class="rounded-circle" width="120px">

<?php else: ?>
    <img src="<?php echo e(asset('/')); ?>/images/listing/client-2.png" alt="User image" class="rounded-circle">
    <?php endif; ?>
</div>

<div class="form-group">
<input type="file" name="userimage2" id="userimage2" class="form-control-file btn btn-primary">
<small id="imageerror2"></small>
</div>

</div>
<div class="">

<div class="form-row mb-2">
<div class="col-sm-6 mb-2 mb-sm-0">
<label for="firstname2" class="font-size-md text-dark font-weight-semibold mb-1">Voornaam
<span class="text-danger">*</span></label>
<input class="form-control" id="firstname2" name="firstname2" type="text" value="<?php echo e(auth()->user()->name); ?>">
<small id="firstname2empty" class="text-danger"></small>
</div>
<div class="col-sm-6">
<label for="lastname2" class="font-size-md text-dark font-weight-semibold mb-1">Achternaam
<span class="text-danger">*</span></label>
<input class="form-control" id="lastname2" name="lastname2" type="text" value="<?php echo e(auth()->user()->userview->lastname); ?>">
<small id="lastname2empty" class="text-danger"></small>
</div>
</div>
<div class="form-row mb-2">
<div class="col-sm-6 mb-2 mb-sm-0">
<label for="email2" class="font-size-md text-dark font-weight-semibold mb-1">E-mail Adres
<span class="text-danger">*</span></label>
<input class="form-control" id="email2" name="email2" type="text" value="<?php echo e(auth()->user()->email); ?>">
<small id="empty2email" class="text-danger"></small>
</div>
<div class="col-sm-6">
<label for="phone2" class="font-size-md text-dark font-weight-semibold mb-1">Telefoon
<span class="text-secondary font-weight-normal">(Optional)</span></label>
<input class="form-control" id="phone2" name="phone2" type="text" value="<?php echo e(auth()->user()->userview->phone); ?>" placeholde="+316652158987">
<small id="phone2error" class="text-danger"></small>
</div>
</div>
<div class="form-group mb-2">
<label for="usercategory2" class="font-size-md text-dark font-weight-semibold mb-1">Voor welke doeleinden gebruikt u de website?</label>
<select class="form-control" name="usercategory2" id="usercategory2"> 
    <?php if(auth()->user()->userview->company == "USER"): ?>
    <option value="USER">For me - like user</option> 
    <option value="Company">For Company, company representer</option> 
    <?php else: ?>
    <option value="Company">For Company, company representer</option> 
    <option value="USER">For me - like user</option> 
    <?php endif; ?>
</select>

</div>
<div class="form-group mb-2">
<label for="bio2" class="font-size-md text-dark font-weight-semibold mb-1">Bio</label>
<textarea class="form-control" id="bio2" name="bio2" placeholder="Korte omschrijving over jou..."><?php echo e(auth()->user()->userview->bio); ?></textarea>
</div>
<div class="form-row mb-6">
<div class="col-md-4 mb-2 mb-md-0">
<label for="linkedin2" class="font-size-md text-dark font-weight-semibold mb-1">LinkedIn
</label>
<input class="form-control" id="linkedin2" name="linkedin2" type="text" placeholder="Twitter URL" value="<?php echo e(auth()->user()->userview->linkedin); ?>">
<small id="linkedin2error" class="text-danger"></small>

</div>
<div class="col-md-4 mb-2 mb-md-0">
<label for="facebook2" class="font-size-md text-dark font-weight-semibold mb-1">Facebook
</label>
<input class="form-control" id="facebook2" name="facebook2" type="text" placeholder="Facebook URL" value="<?php echo e(auth()->user()->userview->facebook); ?>">
<small id="facebook2error" class="text-danger"></small>

</div>
<div class="col-md-4">
<label for="instagram2" class="font-size-md text-dark font-weight-semibold mb-1">Instagram
Plus
</label>
<input class="form-control" id="instagram2" name="instagram2" type="text" placeholder="Instagram URL" value="<?php echo e(auth()->user()->userview->instagram); ?>">
<small id="instagram2error" class="text-danger"></small>
</div>
</div>
<input type="submit" class="btn btn-primary btn-block font-size-lg" value="Save Change">
</form>