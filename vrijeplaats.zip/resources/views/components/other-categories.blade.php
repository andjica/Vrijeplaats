

<section id="section-05" class="pt-11 pb-11">
<div class="container">
<div class="d-flex align-items-center mb-7 flex-wrap flex-sm-nowrap">
<h2 class="mb-3 mb-sm-0">
<span class="font-weight-semibold">Some</span>
<span class="font-weight-light">Tips &amp; Articles</span>
</h2>
<a href="blog-listing-grid.html" class="link-hover-dark-primary ml-0 ml-sm-auto w-100 w-sm-auto">
<span class="font-size-md d-inline-block mr-1">All articles</span>
<i class="fa fa-chevron-right"></i>
</a>
</div>
<div class="row">
<div class="col-md-4 mb-4" data-animate="zoomIn">
<div class="card border-0">
<a href="blog-single-gallery.html" class="hover-scale">
<img src="{{asset('/images/')}}/blog/main-blog-2.jpg" alt="product 1" class="card-img-top image">
</a>
<div class="card-body px-0">
<div class="mb-2"><a href="#" class="link-hover-dark-primary">Tips</a>, <a href="#" class="link-hover-dark-primary">Travel</a></div>
<h5 class="card-title lh-13 letter-spacing-25">
<a href="blog-single-image.html" class="link-hover-dark-primary text-capitalize">
10 best homestay in florencia that you don't miss
out</a>
</h5>
<ul class="list-inline">
<li class="list-inline-item mr-0">
<span class="text-gray">Aug 28th, 2017 by</span>
</li>
<li class="list-inline-item">
<a href="#" class="link-hover-dark-primary">Admin</a>
</li>
</ul>
</div>
</div>
</div>
<div class="col-md-4 mb-4" data-animate="zoomIn">
<div class="card border-0">
<a href="blog-single-gallery.html" class="hover-scale">
<img src="{{asset('/images/')}}/blog/main-blog-3.jpg" alt="product 1" class="card-img-top image">
</a>
<div class="card-body px-0">
<div class="mb-2"><a href="#" class="link-hover-dark-primary">Culture</a></div>
<h5 class="card-title lh-13 letter-spacing-25"><a href="blog-single-gallery.html" class="link-hover-dark-primary text-capitalize">Coffee
On Street &amp; Look Super Car</a>
</h5>
<ul class="list-inline">
<li class="list-inline-item mr-0">
<span class="text-gray">Aug 25th, 2017 by</span>
</li>
<li class="list-inline-item">
<a href="#" class="link-hover-dark-primary">David</a>
</li>
</ul>
</div>
</div>
</div>
<div class="col-md-4 mb-4" data-animate="zoomIn">
<div class="card border-0">
<a href="blog-single-gallery.html" class="hover-scale">
<img src="{{asset('/images/')}}/blog/main-blog-1.jpg" alt="product 1" class="card-img-top image">
</a>
<div class="card-body px-0">
<div class="mb-2"><a href="#" class="link-hover-dark-primary">Location</a></div>
<h5 class="card-title lh-13 letter-spacing-25"><a href="blog-single-gallery.html" class="link-hover-dark-primary">MadCap
Coffee At
Brooklyn Town For Who Love Black
Coffee</a>
</h5>
<ul class="list-inline">
<li class="list-inline-item mr-0">
<span class="text-gray">Aug 19th, 2017 by</span>
</li>
<li class="list-inline-item">
<a href="#" class="link-hover-dark-primary">LoganCee</a>
</li>
</ul>
</div>
</div>
</div>
</div>
</div>
</section>