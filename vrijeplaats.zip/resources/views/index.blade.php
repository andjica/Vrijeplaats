@extends('layouts.template')

@section('content')

  
    
     @include('components.section-01')
     @include('components.section-03')
     @include('components.section-clientreview')

     @include('components.other-categories')






@endsection