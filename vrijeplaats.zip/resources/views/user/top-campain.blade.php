<div class="top-campaign">
<div class="container">
<div class="d-flex top-campaign-container">
<div class="content">
<span class="font-weight-bold">MEGA SALE</span> up to
<span class="font-weight-bold">30% off </span>for 8000+ hotels in
Australia.
Enter code <span class="code">thedir30</span> when booking, <span class="font-weight-bold">take action now!</span>
</div>
<div class=" ml-auto campaign-action">
<a href="#" id="campaign-close-button" class="close-button">
    <i class="fa fa-times"></i></a>
</div>
</div>
</div>
</div>