<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Post;
use App\Image;
use DB;

class PostController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store()
    {
        // request()->validate([
        //     'images' => 'mimes:jpeg,jpg,png',
        //     'category' => 'required|not_in:0',
           
        // ],
        // [
        //     'category.not_in' => 'You must choose category',
        //     'images.mimes' => 'Image must be in: jpeg,jpg,png extensions',
           
        // ]);

        if(request()->images)
        {
            
           
            $image = request()->file('images');
            foreach($image as $img)
            {
                $current = time();
                $name = $current.str_slug(auth()->user()->id).'.'.$img->getClientOriginalExtension();

                $destinationPath = public_path('/images/posts');
    
                $img->move($destinationPath, $name);
    
                
                $pic = new Image();
                $pic->alt= $name;
                $pic->url = $name;
                $pic->post_id = 1;
                try{
                    $pic->save();
                    return redirect()->back()->with('success', 'Je hebt je gegevens succesvol uitgewisseld');
                }
                catch(\Throwable $e)
                {
                    abort(500);
                }
            }
           
        }
        
    }
    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
